package com.noa.eatandshare.model;

public class Review {
    int id;
    User user;
    String date;
    double rate;



}